#include <atmel_start.h>
#include "drv_mxt.h"
extern uint8_t tiny1617_fw[];
uint8_t ii;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
//	ii = tiny1617_fw[0];


	drv_mxt_main();
	
	/* Replace with your application code */
	while (1) {
		
	}
}
